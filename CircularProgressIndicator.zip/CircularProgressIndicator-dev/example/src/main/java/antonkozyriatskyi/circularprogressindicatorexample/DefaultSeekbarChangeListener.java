package antonkozyriatskyi.circularprogressindicatorexample;

import android.widget.SeekBar;

/**
 * Created by Anton on 13.03.2018.
 */

public class DefaultSeekbarChangeListener implements SeekBar.OnSeekBarChangeListener {

    @Override
    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {

    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {

    }
}
