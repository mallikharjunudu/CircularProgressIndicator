package antonkozyriatskyi.circularprogressindicator;

import android.animation.Animator;

/**
 * Created by Anton on 17.03.2018.
 */

class DefaultAnimatorListener implements Animator.AnimatorListener {
    @Override
    public void onAnimationStart(Animator animation, boolean isReverse) {

    }

    @Override
    public void onAnimationEnd(Animator animation, boolean isReverse) {

    }

    @Override
    public void onAnimationStart(Animator animation) {

    }

    @Override
    public void onAnimationEnd(Animator animation) {

    }

    @Override
    public void onAnimationCancel(Animator animation) {

    }

    @Override
    public void onAnimationRepeat(Animator animation) {

    }
}
